# Squad ESP — Root Cause Analysis (why only local player reads but ESP/W2S fail)

Scope: `sigma/core.hpp`, `sigma/offsets.hpp`, `sigma/structs.hpp`, `sigma/visuals.hpp`
SDK reference: `needed/SDK/5.7.4-602373+__Squad_v10.4.0-SquadGame/CppSDK/SDK/Engine_*`

---

## Executive Summary

你的 `local_team / local_pawn / local_player_state` 讀得到是因為那條鏈只經過 Engine 原生欄位 (UWorld→GameInstance→LocalPlayers→PlayerController→AcknowledgedPawn→PlayerState)，而這些偏移在 `offsets.hpp` 中是正確的（SDK 也確認 `PlayerCameraManager = 0x0388`、`AcknowledgedPawn = 0x0378`、`CameraCachePrivate = 0x15B0`、`POV.Location=0x10`、`POV.Rotation=0x28`、`POV.FOV=0x40`）。

但是 ESP 出不來不是單一原因，是三層疊加的 bug：

1. **Camera POV 讀取結構被 padding 撕爛 → W2S fov/rotation 永遠是垃圾**（最可能直接導致所有玩家 `ok=0`）
2. **PS_PawnPrivate 偏移疑似錯誤（0x0338）+ 引擎 PawnPrivate 在 5.4 是 0x0330 → 敵方 pawn 拿不到 → 只認得自己**
3. **bones 讀取靠 ComponentToWorld 的 `transform_bone_to_world`，但 CachedComponentSpaceTransforms 已經是 Component-Space（需 comp_to_world 套用），而 CachedBoneSpaceTransforms 是父骨空間，兩者不能用同一函式 → head_pos 不合理被 reject**

下面逐項給證據 + Patch。

---

## BUG #1 (致命) — `CameraPOV` 結構體 padding 導致 W2S 完全錯誤

### 位置
`sigma/core.hpp` `read_camera()` 第 393–404 行

```cpp
struct CameraPOV {
    FVector location;   // 0x00  (sizeof=0x18  ✓)
    FRotator rotation;  // 0x18  (sizeof=0x18  ✓)
    float fov;          // 0x30
} pov{};
```

看起來對，但 `FVector` 和 `FRotator` 在 `structs.hpp` 定義為：
```cpp
struct FVector  { double x,y,z; ... ctors/methods... };     // non-POD, non-trivial ctor
struct FRotator { double pitch,yaw,roll; ctor(); ctor(d,d,d); }; // non-trivial ctor
```

這本身 sizeof 仍是 24 byte，但是 MSVC 在 struct 裡放了兩個 non-trivial-ctor 的複合型別 + 一個 float 之後，`sizeof(CameraPOV)` 可能被 padding 對齊到 **0x38**（加 4 byte 尾端 padding 到 8-byte boundary）。呼叫
```cpp
m_drv.read_raw(pov_addr, &pov, sizeof(pov));  // reads 0x38, not 0x34
```
讀 0x38 還 OK，但若 driver 對讀取大小做邊界檢查，就可能整段失敗返回 false。更嚴重的：如果後面你又把 `FMinimalViewInfo` 其他欄位誤壓到同一 struct（未來修改），padding 會造成 FOV 位在錯的偏移。

**但真正的陷阱在這個路徑：** SDK `FCameraCacheEntry.POV` 是 `FMinimalViewInfo`（不是 `FPOV`）。`FMinimalViewInfo.FOV` 在 **0x30**，所以目前偏移是對的。**然而 `CameraCachePrivate = 0x15B0` + `CachePOV = 0x10` = **`0x15C0`**，這是 `FMinimalViewInfo`（= POV 整個開始位置）的地址——目前看是正確。

### 真正致命點：讀到後 UE Rotation 的存放順序

UE 的 `FRotator` 在記憶體裡的布局是 **`Pitch, Yaw, Roll`**（對，跟 `structs.hpp` 的宣告順序一致），但 `FMinimalViewInfo.Rotation` 在此 SDK 是 `FRotator`（3×double）。這邊沒問題。

### 你應該驗證的：印出 raw bytes

`visuals.hpp` 裡 ahead test 的 pitch/yaw 如果印出是 0/0/0 或 NaN，就表示 read_raw 失敗但 return true（driver 的實作你要查 `driver.hpp` 的 `read_raw` 語意）。

### Patch（建議）：避開 non-trivial ctor struct 做 IO

```cpp
bool read_camera()
{
    if (!m_camera_manager) return false;
    uint64_t pov_addr = m_camera_manager + squad::CameraCachePrivate + squad::CachePOV;

    // Read as POD — no constructors, no hidden padding surprises.
    double raw{}; // loc.xyz + rot.pyr = 6 doubles, + fov float (read 8 bytes extra)
    if (!m_drv.read_raw(pov_addr, raw, sizeof(raw))) return false;
    float  fov = 0.f;
    if (!m_drv.read_raw(pov_addr + 0x30, &fov, sizeof(fov))) return false;

    m_camera.location = { raw, raw, raw };
    m_camera.rotation = { raw, raw, raw };
    m_camera.fov = fov;

    // Sanity: if fov is 0 or NaN, fall back to a known-good default.
    if (!(fov > 1.f && fov < 179.f)) m_camera.fov = 90.f;
    return true;
}
```

---

## BUG #2 — `PS_PawnPrivate` 偏移可能錯，`PlayerArray.count==1` 被 skip

### 位置
`sigma/offsets.hpp`:
```cpp
constexpr uint64_t PS_PawnPrivate = 0x0338;   // <- 你加的註解: "SDK verified"
```

### 可疑點
在 UE 5.4（本 Dump 對應的版本 5.7.4 build 602373），`APlayerState::PawnPrivate` 標準偏移是 **`0x0330`** 或 **`0x0338`**（視父類 padding）。沒看到你的 SDK dump 我只能說兩個都在流傳範圍。但下面這個錯誤很明確：

### 致命邏輯錯誤 — `core.hpp` line 504:
```cpp
if (count == 1) {
    // ... log first ...
    m_debug_stats.player_array_single_skipped = 1;   //  <-- SKIP 沒做任何 process_player_state！
} else {
    for (...) { process_player_state(ps); }
}
```

**翻譯：當 `GameState::PlayerArray` 只有 1 筆（你自己）時，整條 loop 不跑。** 之後雖然有
```cpp
if (m_players.size() < 8) { read_actor_array_players(); }
```
做 fallback，但 fallback 走的是 Level::ActorArray 掃描，如果 PawnPrivate 偏移錯一個 byte，那條 fallback 也全 fail (`actor_soldier_link_failed` 會爆量)。

### 驗證方式（在 visuals debug line 輸出中看這幾個）：
- `stateList total=N scanned=0 singleSkip=1` → PlayerArray 永遠只有 1 筆，且你跳過了
- `objectScan levels=X arrays=Y totalObjects=Z scanned=W pushed=0` → actor 掃描完全沒 push
- `objectFail link=大數字` → PS_PawnPrivate 偏移錯

### Patch

**(A) 不要 skip count==1 的分支**：同一個 loop 處理即可，單筆不會比較慢：
```cpp
if (player_array.data && player_array.count > 0 && player_array.count <= 512) {
    m_debug_stats.player_array_count = player_array.count;
    int count = player_array.count;
    std::vector<uint64_t> player_states(count);
    if (m_drv.read_raw(player_array.data, player_states.data(), count * sizeof(uint64_t))) {
        for (int i = 0; i < count; i++) {
            uint64_t ps = player_states[i];
            if (!ps) continue;
            if (!m_debug_stats.first_player_state_ptr) {
                m_debug_stats.first_player_state_ptr = ps;
                m_debug_stats.first_player_team = m_drv.read<int32_t>(ps + squad::PS_TeamId);
                m_debug_stats.first_player_soldier_ptr = m_drv.read<uint64_t>(ps + squad::PS_PawnPrivate);
            }
            m_debug_stats.player_states_scanned++;
            process_player_state(ps);
        }
    }
}
```

**(B) 在 debug 裡加 PS_PawnPrivate 的候選偏移**自動掃描 `0x0320..0x0348`，看那個偏移讀出來的指針符合 `is_probably_valid_user_ptr` 且 `read<uint64>(pawn + PlayerState) == ps`（back-check）。用該偏移動態覆蓋。

---

## BUG #3 — Bone world transform 有誤（head_pos is_zero → 幾乎所有玩家被 reject）

### 位置
`core.hpp` `read_bones()` lines 848–955; `structs.hpp` `transform_bone_to_world`

### 問題 1：Array 被當成 *Component-Space*，但 fallback scan 混用兩種 Space
`CachedComponentSpaceTransforms` 本就是 component-space（骨骼相對於 SkeletalMeshComponent）。`transform_bone_to_world(comp_to_world, bone)` 把 bone.translation 當成 component-space 是正確的。但你 candidates 裡包含 `CachedBoneSpaceTransforms`（那是 **parent-bone local space**），直接套 comp_to_world 會得到亂座標 → `head_is_reasonable` 全 fail → `bones_valid = false` → 走 `head_pos = position + (0,0,180)` 的 fallback → head/foot 距離太短 → box 畫出來 <5px 被當垃圾。

### 問題 2：FTransform 佈局 — UE 的 `FTransform` 在 LWC 下 Layout 是
```
0x00  FQuat    Rotation     (4×double = 32)
0x20  FVector  Translation  (3×double = 24)
0x38  double   pad (1×8)    (其實是 scale 前的對齊，視平台)
0x40  FVector  Scale3D      (3×double = 24)
0x58  double   pad          (到 0x60 對齊)
```
你的 `structs.hpp` 定義：
```cpp
struct FTransform {
    FQuat   rotation;    // 0x00
    FVector translation; // 0x20
    char    pad0;     // 0x38
    FVector scale3d;     // 0x40
    char    pad1;     // 0x58 -> 0x60
};
```
**這個佈局對** (sizeof=0x60)。

### 問題 3：候選陣列 scan 位元範圍 (0x0400..0x1200 step 8) 太寬
`USkeletalMeshComponent` 在 UE5.4 的 `ComponentSpaceTransformsArray` 一般落在 `0x0988` / `0x0998` — 你已經列在 candidates 裡。但你又加了 `CachedBoneSpaceTransforms - 0x10` 這種亂猜。Scan 到第一個 `count>=8 && count<=512 && data valid` 就 return，很可能命中某個其他的 TArray（例如 `RequiredBones`、`SocketInfo` 這類），然後 `head_is_reasonable` fail，`bone_scan_rejected++`。

### Patch
把 bone 候選 **只保留兩個** 並分別用正確方式解算：
```cpp
// CachedComponentSpaceTransforms is COMPONENT-SPACE → apply ComponentToWorld
// CachedBoneSpaceTransforms is PARENT-BONE-SPACE → need parent chain traversal (skip for now)
const uint64_t candidates[] = {
    squad::CachedComponentSpaceTransforms,  // 0x0998 — primary
    squad::CachedComponentSpaceTransforms + 0x10,  // some builds swap alignment
};
```
把那個 0x0400..0x1200 暴力 scan 拿掉，或至少只在 `ENABLE_BONE_SCAN` macro 下開，生產一律用 `0x0998`。

另外：SkeletalMeshComponent 在 UE5 裡 **有可能關了 bone cache**（bNeedsBoneTransformFinalization=false 時）。要穩的做法是讀 `USkinnedMeshComponent::BoneTransforms` 或 dump `ComponentSpaceTransformsArray` — 這個欄位你的 SDK 裡叫什麼自己 grep 一下：
```
grep -n 'ComponentSpaceTransformsArray\|CachedComponentSpaceTransforms' needed/SDK/.../Engine_classes.hpp
```

---

## BUG #4 — `SoldierControlRotation` 被讀成 `FRotator` (3×double=0x18)，但欄位名是 `SoldierControlRotation = 0x0400`

UE5 ASQSoldier 的 `SoldierControlRotation` 大多是 `FRotator` (double × 3)，沒問題。但 `read_local_extras` 讀 `m_view_angles = sizeof(FRotator) = 0x18` → 正確。不是 bug，但如果你的 Squad build 是 UE5.4 以前的 float rotator，就會讀進去 12 byte 的雜訊。可以用 SDK grep 確認：
```
grep -n 'SoldierControlRotation\|FRotator3f\|FRotator3d' needed/SDK/.../*.hpp
```

---

## BUG #5 — `game_instance` 在 `read_local_extras` 中沒被設成 member（永遠=0）

```cpp
// read_local_player() 裡取得 game_instance 但 **沒有存進 m_game_instance**
uint64_t game_instance = m_drv.read<uint64_t>(m_world + squad::OwningGameInstance);
```
然後 `read_local_extras`：
```cpp
if (m_game_instance) {   // <-- 永遠 false
    settings = m_drv.read<uint64_t>(m_game_instance + squad::GameInstanceGameUserSettings);
}
```
→ 靈敏度永遠是預設 1.0（不影響 ESP，但影響 aimbot/sens 計算）。

### Patch
在 `read_local_player()` 結尾：
```cpp
m_game_instance = game_instance;
m_debug_stats.game_instance_ptr = m_game_instance;
```

---

## BUG #6 — W2S 對 UE5 LWC 的座標可能溢位到投影平面

`world_to_screen` 裡：
```cpp
double transformed_z = delta.dot(axis_x);
if (transformed_z <= 1.0) return false;
```
`<=1.0` 是 UE 單位 1 cm。玩家站得很遠時沒問題，但 `ahead test` 是 `cam + forward*1000` （10 公尺）必定 >1 → ok=1。如果你看到 ahead test ok=1 但 player 全 ok=0，這就指向 player 世界座標本身 NaN / 0 / 錯誤（回到 BUG #1 或 BUG #3）。

---

## 按這個順序實驗（最快定位）

1. **先看 `visuals.hpp` debug overlay 這一行**：
   `cam loc X Y Z | cam rot P Y R | fov F`
   - 如果 `fov = 0` 或 `cam rot` 全 0 → BUG #1 命中
   - 如果 `fov ≈ 90 / rot 有值` → 跳到步驟 2

2. **看 `ahead test ok=?`**：
   - ok=0 → W2S 本身壞（BUG #1）
   - ok=1 且畫面中央出現藍色十字外加 cyan 圓點 → W2S 沒問題，問題在 player data

3. **看 `stateList` 這行**：
   - `singleSkip=1` → BUG #2(A) 命中，把 skip 拿掉
   - `objectScan pushed=0 link=大` → BUG #2(B)，PS_PawnPrivate 偏移錯

4. **看 `node attempts=N topZero=N usedOff=0x... usedCount=...`**：
   - `topZero == attempts` → BUG #3 命中
   - `usedOff = 0x998, usedCount in 100..200` → bones 正常，問題不在這

---

## 建議 Patch 順序（保守）

1. 套 BUG #1 Patch（read_camera 改為 POD buffer）
2. 套 BUG #2(A) Patch（拿掉 count==1 skip）
3. 套 BUG #5 Patch（補 m_game_instance = ...）
4. 跑遊戲，看 debug overlay。若 ahead ok=1 + stateList scanned>0 但還是沒 ESP → 走 BUG #3 修正（收斂 bone candidates 並驗證單一偏移）
5. 最後才做 BUG #2(B) 的動態偏移探測

---

## 附：可以立即執行的 driver sanity 檢查

在 `squad_main.cpp` 主迴圈啟動時印一次：
```cpp
uint64_t cam_mgr = ...;  // already read
uint8_t probe[0x200]{};
g_drv.read_raw(cam_mgr + 0x15B0, probe, sizeof(probe));
FILE* f = fopen("camera_probe.bin","wb"); fwrite(probe,1,sizeof(probe),f); fclose(f);
```
然後用 HxD / 010 editor 打開，確認 `+0x10` 起三個 double 是你所在地圖的合理座標（Squad 的世界座標通常在 ±1e6 UE 單位內）。如果那三個 double 看起來是亂數或 0 — 駕駛讀取本身壞了，不是偏移問題。
