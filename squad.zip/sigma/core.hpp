#pragma once
#include "driver.hpp"
#include "structs.hpp"
#include "offsets.hpp"
#include "object_resolver.hpp"
#include <fstream>
#include <iomanip>
#include <vector>
#include <string>
#include <cmath>

// ============================================================================
// Squad Core - scene traversal, object loop, node reading, projection
// External data access layer
// ============================================================================

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// ---------------------------------------------------------------------------
// Per-entry cached data
// ---------------------------------------------------------------------------
struct PlayerData
{
    uint64_t    actor;
    uint64_t    mesh;           // USkeletalMeshComponent*
    uint64_t    player_state;
    FVector     position;       // root component world position
    FVector     head_pos;       // bone head world position
    float       health;
    int32_t     team_id;
    uint8_t     dying_flags;    // bit0=dying, bit2=bleeding, bit3=wounded
    bool        is_alive;
    bool        is_visible;     // placeholder for future LOS check
    double      distance;       // meters from local player
    std::wstring name;

    // Node world positions used by the visualization layer
    FVector bones_ws[141];      // full node array world positions
    bool    bones_valid;
    uint64_t last_seen_frame;
};

struct CoreDebugStats
{
    int player_array_count = 0;
    int player_states_scanned = 0;
    int with_valid_player_state = 0;
    int valid_team = 0;
    int valid_soldier = 0;
    int valid_health = 0;
    int valid_bones = 0;
    int pushed_players = 0;

    int actor_level_count = 0;
    int actor_arrays_scanned = 0;
    int actor_array_count = 0;
    int actors_scanned = 0;
    int actors_with_player_state = 0;
    int actor_scan_candidates = 0;
    int actor_scan_actor_attempts = 0;
    int actor_scan_soldier_attempts = 0;
    int actor_scan_pushed = 0;

    int actor_invalid_ptr = 0;
    int actor_backcheck_failed = 0;
    int actor_mesh_failed = 0;
    int actor_root_failed = 0;
    int actor_health_failed = 0;
    int actor_bones_failed = 0;
    int actor_estimated_head = 0;
    int actor_bad_team = 0;
    int actor_soldier_link_failed = 0;
    int player_array_single_skipped = 0;

    int bone_attempts = 0;
    int bone_comp_fail = 0;
    int bone_array_fail = 0;
    int bone_array_invalid = 0;
    int bone_read_fail = 0;
    int bone_head_zero = 0;
    uint64_t first_bone_mesh = 0;
    uint64_t first_bone_array = 0;
    int first_bone_count = 0;
    int first_bone_max = 0;
    uint64_t first_bone_offset = 0;
    int bone_scan_checked = 0;
    int bone_scan_candidates = 0;
    int bone_scan_rejected = 0;
    uint64_t first_scan_bone_offset = 0;
    uint64_t first_scan_bone_array = 0;
    int first_scan_bone_count = 0;
    int first_scan_bone_max = 0;
    uint64_t used_bone_offset = 0;
    int used_bone_count = 0;
    int cache_added_players = 0;
    int cache_size = 0;

    uint64_t game_state_ptr = 0;
    uint64_t local_player_state_ptr = 0;
    uint64_t local_pawn_ptr = 0;
    uint64_t local_ps_soldier_ptr = 0;
    uint64_t first_player_state_ptr = 0;
    uint64_t first_player_soldier_ptr = 0;
    int first_player_team = 0;
    int local_team = -1;

    uint64_t first_actor_ptr = 0;
    uint64_t first_actor_player_state_ptr = 0;
    uint64_t first_actor_soldier_ptr = 0;
    int first_actor_team = 0;
    
    uint64_t world_ptr = 0;
    uint64_t persistent_level_ptr = 0;
    uint64_t game_instance_ptr = 0;
    uint64_t local_players_array_ptr = 0;
    uint64_t local_player_ptr = 0;
    
    uint64_t ps_handle_raw = 0;  // Debug: raw PlayerState handle
    uint64_t gobjects_ptr = 0;   // Debug: GObjects pointer
    uint64_t objects_array = 0;  // Debug: Objects array
};

// ---------------------------------------------------------------------------
// Camera data for W2S
// ---------------------------------------------------------------------------
struct CameraData
{
    FVector  location;
    FRotator rotation;
    float    fov;
};

// ---------------------------------------------------------------------------
// SquadCore
// ---------------------------------------------------------------------------
class SquadCore
{
public:
    SquadCore(SquadDriver& drv) : m_drv(drv), m_resolver(drv) {}

    // -----------------------------------------------------------------------
    // Update all game state (call once per frame)
    // -----------------------------------------------------------------------
    bool update(int screen_w, int screen_h)
    {
        m_screen_w = screen_w;
        m_screen_h = screen_h;
        m_players.clear();
        m_debug_stats = {};
        m_frame_index++;

        if (!read_world()) return false;
        read_local_player();  // Don't fail if this fails
        read_local_extras();  // Read local position BEFORE camera
        read_camera();        // Don't fail if this fails
        read_players();
        merge_player_cache();

        static int frame_count = 0;
        if (frame_count++ % 60 == 0) {
            std::ofstream log("update_debug.txt", std::ios::trunc);
            log << "Frame: " << m_frame_index << "\n";
            log << "Players in m_players: " << m_players.size() << "\n";
            log << "Camera valid: " << (m_camera_manager ? "yes" : "no") << "\n";
            log << "Local pawn: 0x" << std::hex << m_local_pawn << "\n";
            log << "Local position: " << std::dec << m_local_position.x << ", " << m_local_position.y << ", " << m_local_position.z << "\n";
            log.close();
        }

        return true;
    }

    // Accessors
    const std::vector<PlayerData>& players() const { return m_players; }
    const CameraData& camera() const { return m_camera; }
    int32_t local_team() const { return m_local_team; }
    uint64_t local_pawn() const { return m_local_pawn; }
    uint64_t local_controller() const { return m_local_controller; }
    uint64_t local_player_state() const { return m_local_player_state; }

    // View angles from ASQSoldier::ControlRotation (double precision)
    FRotator view_angles() const { return m_view_angles; }

    // Active sensitivity derived from USQGameUserSettings
    float sensitivity() const { return m_sensitivity; }

    float soldier_sensitivity() const { return m_soldier_sensitivity; }
    float steady_sensitivity() const { return m_steady_aim_sensitivity; }
    float global_sensitivity() const { return m_global_sensitivity; }

    // Is local player ADS?
    bool is_ads() const { return m_is_ads; }
    bool is_focusing() const { return m_is_focusing; }
    float focus_zoom_alpha() const { return m_focus_zoom_alpha; }

    // Current local sway/punch values
    FRotator local_weapon_punch_sway() const { return m_weapon_punch_sway; }
    FRotator local_weapon_punch_alignment() const { return m_weapon_punch_alignment; }

    // Local player world position
    FVector local_position() const { return m_local_position; }
    const CoreDebugStats& debug_stats() const { return m_debug_stats; }

    // -----------------------------------------------------------------------
    // World-to-Screen (external W2S from camera rotation + FOV)
    // -----------------------------------------------------------------------
    bool world_to_screen(const FVector& world, FVector2D& screen) const
    {
        if (m_screen_w <= 0 || m_screen_h <= 0) return false;

        // UE5: X=Forward, Y=Right, Z=Up
        // Use correct axis calculation from reference code
        double pitch_rad = m_camera.rotation.pitch * (M_PI / 180.0);
        double yaw_rad   = m_camera.rotation.yaw   * (M_PI / 180.0);
        double roll_rad  = m_camera.rotation.roll  * (M_PI / 180.0);

        double cp = cos(pitch_rad), sp = sin(pitch_rad);
        double cy = cos(yaw_rad),   sy = sin(yaw_rad);
        double cr = cos(roll_rad),  sr = sin(roll_rad);

        // Forward vector (X axis)
        FVector axis_x = { cp * cy, cp * sy, sp };
        
        // Right vector (Y axis)
        FVector axis_y = { sr * sp * cy - cr * sy, sr * sp * sy + cr * cy, -sr * cp };
        
        // Up vector (Z axis) - FIX: negate X and Y components
        FVector axis_z = { -(cr * sp * cy + sr * sy), -(cr * sp * sy - sr * cy), cr * cp };

        FVector delta = world - m_camera.location;

        double transformed_z = delta.dot(axis_x);
        
        static int debug_count = 0;
        if (debug_count < 5) {
            std::ofstream log("w2s_debug.txt", std::ios::app);
            log << "World: " << world.x << ", " << world.y << ", " << world.z << "\n";
            log << "Camera: " << m_camera.location.x << ", " << m_camera.location.y << ", " << m_camera.location.z << "\n";
            log << "Delta: " << delta.x << ", " << delta.y << ", " << delta.z << "\n";
            log << "Transformed Z: " << transformed_z << "\n";
            log << "Pass Z check: " << (transformed_z > 1.0 ? "yes" : "NO") << "\n\n";
            log.close();
            debug_count++;
        }
        
        if (transformed_z <= 1.0) return false;

        double transformed_x = delta.dot(axis_y);
        double transformed_y = delta.dot(axis_z);

        double fov_rad = m_camera.fov * (M_PI / 360.0);
        double tan_fov = tan(fov_rad);
        if (tan_fov <= 0.0001) return false;

        double half_w = m_screen_w * 0.5;
        double half_h = m_screen_h * 0.5;
        double focal = half_w / tan_fov;

        screen.x = half_w + (transformed_x / transformed_z) * focal;
        screen.y = half_h - (transformed_y / transformed_z) * focal;

        return (screen.x >= -50 && screen.x <= m_screen_w + 50 &&
                screen.y >= -50 && screen.y <= m_screen_h + 50);
    }

    // -----------------------------------------------------------------------
    // Get bone world position for a player
    // -----------------------------------------------------------------------
    FVector get_bone_world(const PlayerData& p, int bone_index) const
    {
        if (!p.bones_valid || bone_index < 0 || bone_index > 140)
            return {};
        return p.bones_ws[bone_index];
    }

private:
    SquadDriver& m_drv;

    // World state
    uint64_t m_world = 0;
    uint64_t m_game_state = 0;
    uint64_t m_game_instance = 0;
    uint64_t m_local_player = 0;
    uint64_t m_local_controller = 0;
    uint64_t m_local_pawn = 0;
    uint64_t m_local_player_state = 0;
    uint64_t m_camera_manager = 0;
    uint64_t m_persistent_level = 0;
    int32_t  m_local_team = -1;

    ObjectResolver m_resolver;
    CameraData m_camera{};
    FRotator   m_view_angles{};
    FRotator   m_weapon_punch_sway{};
    FRotator   m_weapon_punch_alignment{};
    FVector    m_local_position{};
    float      m_sensitivity = 1.0f;
    float      m_global_sensitivity = 1.0f;
    float      m_steady_aim_sensitivity = 1.0f;
    float      m_soldier_sensitivity = 1.0f;
    float      m_focus_zoom_alpha = 0.0f;
    bool       m_is_ads = false;
    bool       m_is_focusing = false;
    CoreDebugStats m_debug_stats{};
    std::vector<PlayerData> m_players;
    std::vector<PlayerData> m_player_cache;
    uint64_t m_frame_index = 0;
    int m_screen_w = 1920;
    int m_screen_h = 1080;

    // -----------------------------------------------------------------------
    // Read world pointer - Find via GObjects
    // -----------------------------------------------------------------------
    bool read_world()
    {
        uint64_t base = m_drv.base();
        m_world = m_drv.read<uint64_t>(base + squad::GWorld);
        
        {
            std::ofstream log("read_world_debug.txt");
            log << std::hex;
            log << "Base: 0x" << base << "\n";
            log << "GWorld offset: 0x" << squad::GWorld << "\n";
            log << "World: 0x" << m_world << "\n";
            if (!m_world) {
                log << "ERROR: World is NULL!\n";
                log.close();
                return false;
            }
            log << "GameState offset: 0x" << squad::GameState << "\n";
            log << "Reading GameState from: 0x" << (m_world + squad::GameState) << "\n";
            log.close();
        }
        
        if (!m_world) return false;

        m_persistent_level = m_drv.read<uint64_t>(m_world + squad::PersistentLevel);
        m_game_state = m_drv.read<uint64_t>(m_world + squad::GameState);

        {
            std::ofstream log("read_world_debug.txt", std::ios::app);
            log << "GameState value: 0x" << std::hex << m_game_state << "\n";
            log << "Returning TRUE\n";
            log.close();
        }

        m_debug_stats.world_ptr = m_world;
        m_debug_stats.persistent_level_ptr = m_persistent_level;
        m_debug_stats.game_state_ptr = m_game_state;

        return true;
    }

    // -----------------------------------------------------------------------
    // Read local player info
    // -----------------------------------------------------------------------
    bool read_local_player()
    {
        uint64_t game_instance = m_drv.read<uint64_t>(m_world + squad::OwningGameInstance);
        if (!game_instance) {
            std::ofstream("local_player_fail.txt") << "GameInstance is NULL\n";
            return false;
        }
        // FIX: persist game instance so read_local_extras() can reach GameUserSettings.
        m_game_instance = game_instance;
        m_debug_stats.game_instance_ptr = game_instance;

        struct { uint64_t data; int32_t count; int32_t max; } local_players_array{};
        m_drv.read_raw(game_instance + squad::ULocalPlayers, &local_players_array, sizeof(local_players_array));
        
        if (!local_players_array.data || local_players_array.count == 0) {
            std::ofstream log("local_player_fail.txt");
            log << "LocalPlayers array invalid: data=0x" << std::hex << local_players_array.data 
                << " count=" << std::dec << local_players_array.count << "\n";
            return false;
        }

        uint64_t local_player = m_drv.read<uint64_t>(local_players_array.data);
        if (!local_player) {
            std::ofstream("local_player_fail.txt") << "LocalPlayer is NULL\n";
            return false;
        }

        m_local_controller = m_drv.read<uint64_t>(local_player + squad::PlayerController);
        if (!m_local_controller) {
            std::ofstream("local_player_fail.txt") << "LocalController is NULL\n";
            return false;
        }

        m_camera_manager = m_drv.read<uint64_t>(m_local_controller + squad::PlayerCameraManager);
        m_local_pawn = m_drv.read<uint64_t>(m_local_controller + squad::AcknowledgedPawn);

        std::ofstream log("local_player_success.txt");
        log << std::hex;
        log << "GameInstance: 0x" << game_instance << "\n";
        log << "LocalPlayer: 0x" << local_player << "\n";
        log << "LocalController: 0x" << m_local_controller << "\n";
        log << "CameraManager: 0x" << m_camera_manager << "\n";
        log << "LocalPawn: 0x" << m_local_pawn << "\n";

        if (m_local_pawn) {
            uint64_t player_state = m_drv.read<uint64_t>(m_local_pawn + squad::PlayerState);
            if (player_state) {
                m_local_player_state = player_state;
                m_local_team = m_drv.read<int32_t>(player_state + squad::PS_TeamId);
                log << "PlayerState: 0x" << player_state << "\n";
                log << "Team: " << std::dec << m_local_team << "\n";

                // ----- ONE-SHOT DYNAMIC OFFSET PROBE -----
                // The local PS is a known-good (PS, Pawn, Team) triple.
                // Scan its first 0x800 bytes to discover the REAL offsets.
                static bool probed = false;
                if (!probed) {
                    probed = true;
                    std::ofstream pr("ps_offset_probe.txt");
                    pr << std::hex;
                    pr << "local_ps   = 0x" << player_state << "\n";
                    pr << "local_pawn = 0x" << m_local_pawn << "\n";
                    pr << "current PS_PawnPrivate = 0x" << squad::PS_PawnPrivate << "\n";
                    pr << "current PS_TeamId      = 0x" << squad::PS_TeamId << "\n\n";

                    // Bulk-read 0x800 bytes of the PS
                    uint8_t buf[0x800] = {};
                    if (m_drv.read_raw(player_state, buf, sizeof(buf))) {
                        pr << "-- ptr offsets equal to m_local_pawn (= PS_PawnPrivate candidates) --\n";
                        for (size_t off = 0; off + 8 <= sizeof(buf); off += 8) {
                            uint64_t v = 0;
                            for (int b = 0; b < 8; b++) v |= ((uint64_t)buf[off+b]) << (b*8);
                            if (v == m_local_pawn) {
                                pr << "  +0x" << off << "\n";
                            }
                        }
                        pr << "\n-- int32 offsets with value 0/1/2 (= PS_TeamId candidates) --\n";
                        for (size_t off = 0; off + 4 <= sizeof(buf); off += 4) {
                            int32_t v = 0;
                            for (int b = 0; b < 4; b++) v |= ((int32_t)buf[off+b]) << (b*8);
                            if (v == 0 || v == 1 || v == 2) {
                                pr << "  +0x" << off << " = " << std::dec << v << std::hex << "\n";
                            }
                        }
                        pr << "\n-- raw hex dump first 0x300 --\n";
                        for (size_t off = 0; off < 0x300; off += 16) {
                            pr << "+0x";
                            if (off < 0x100) pr << "0";
                            if (off < 0x10)  pr << "0";
                            pr << off << ":";
                            for (int b = 0; b < 16; b++) {
                                uint8_t x = buf[off+b];
                                pr << " ";
                                if (x < 0x10) pr << "0";
                                pr << (int)x;
                            }
                            pr << "\n";
                        }
                    } else {
                        pr << "FAILED to bulk-read PS\n";
                    }
                    pr.close();
                }
            }
        }

        return true;
    }

    // -----------------------------------------------------------------------
    // Read camera (from PlayerCameraManager)
    // -----------------------------------------------------------------------
    bool read_camera()
    {
        if (!m_camera_manager) return false;

        // CameraCachePrivate is an embedded FCameraCacheEntry at +0x15B0
        // FCameraCacheEntry.POV (FMinimalViewInfo) is at +0x10
        //   FMinimalViewInfo.Location  0x00  FVector  (3*double=0x18)
        //   FMinimalViewInfo.Rotation  0x18  FRotator (3*double=0x18)
        //   FMinimalViewInfo.FOV       0x30  float
        // IMPORTANT: do NOT reinterpret into a struct containing FVector/FRotator
        // (non-trivial ctors) for binary IO - MSVC pads/initializes unpredictably.
        // Read into a POD double[] + float and assign explicitly.
        uint64_t pov_addr = m_camera_manager + squad::CameraCachePrivate + squad::CachePOV;

        // Use 6 individual doubles laid out contiguously in a struct - this
        // sidesteps an editor pipeline that strips C array subscripts on save.
        struct PovRaw { double lx, ly, lz, rp, ry, rr; } raw{};
        if (!m_drv.read_raw(pov_addr, &raw, sizeof(raw)))
            return false;

        float fov = 0.f;
        if (!m_drv.read_raw(pov_addr + 0x30, &fov, sizeof(fov)))
            return false;

        m_camera.location = { raw.lx, raw.ly, raw.lz };
        m_camera.rotation = { raw.rp, raw.ry, raw.rr };

        // Sanity-clamp FOV - if garbage, fall back to 90 so W2S still works.
        if (fov > 1.f && fov < 179.f) m_camera.fov = fov;
        else m_camera.fov = 90.f;

        return true;
    }


    // -----------------------------------------------------------------------
    // Read local player extras: view angles, sensitivity, ADS, position
    // -----------------------------------------------------------------------
    void read_local_extras()
    {
        if (!m_local_pawn) return;

        // Read soldier-side aim state / sway in one shot
        std::vector<SquadDriver::BatchReq> local_batch = {
            { m_local_pawn + squad::SoldierControlRotation, sizeof(FRotator), &m_view_angles },
            { m_local_pawn + squad::WeaponPunchSway, sizeof(FRotator), &m_weapon_punch_sway },
            { m_local_pawn + squad::WeaponPunchAlignment, sizeof(FRotator), &m_weapon_punch_alignment },
            { m_local_pawn + squad::FocusZoomAlpha, sizeof(float), &m_focus_zoom_alpha },
            { m_local_pawn + squad::IsFocusing, sizeof(bool), &m_is_focusing },
        };
        m_drv.batch_read(local_batch);

        // Squad settings live in USQGameInstance -> GameUserSettings
        uint64_t settings = 0;
        if (m_game_instance) {
            settings = m_drv.read<uint64_t>(m_game_instance + squad::GameInstanceGameUserSettings);
        }

        if (settings) {
            float global_sens = 1.0f;
            float steady_sens = 1.0f;
            float soldier_sens = 1.0f;

            std::vector<SquadDriver::BatchReq> sens_batch = {
                { settings + squad::SettingsGlobalSensitivity, sizeof(float), &global_sens },
                { settings + squad::SettingsSteadyAimSensitivity, sizeof(float), &steady_sens },
                { settings + squad::SettingsSoldierSensitivity, sizeof(float), &soldier_sens },
            };
            if (m_drv.batch_read(sens_batch)) {
                if (global_sens > 0.001f && global_sens < 100.f)  m_global_sensitivity = global_sens;
                if (steady_sens > 0.001f && steady_sens < 100.f)  m_steady_aim_sensitivity = steady_sens;
                if (soldier_sens > 0.001f && soldier_sens < 100.f) m_soldier_sensitivity = soldier_sens;
            }
        }

        // Practical ADS proxy for external: focus state / zoom alpha.
        // This is sufficient for FOV switching and steady-aim sensitivity selection.
        m_is_ads = m_is_focusing || (m_focus_zoom_alpha > 0.05f);

        float base_sens = (m_soldier_sensitivity > 0.001f) ? m_soldier_sensitivity : m_global_sensitivity;
        m_sensitivity = m_is_ads
            ? ((m_steady_aim_sensitivity > 0.001f) ? m_steady_aim_sensitivity : base_sens)
            : base_sens;

        // Local position - read from RelativeLocation
        uint64_t local_root = m_drv.read<uint64_t>(m_local_pawn + squad::RootComponent);
        if (local_root) {
            m_drv.read_raw(local_root + squad::RelativeLocation, &m_local_position, sizeof(FVector));
        }
    }

    // -----------------------------------------------------------------------
    // Read all players from AGameStateBase::PlayerArray, then fall back to
    // level actor traversal when the replicated PlayerArray only contains us.
    // -----------------------------------------------------------------------
    void read_players()
    {
        {
            std::ofstream log("playerarray_debug.txt");
            log << std::hex;
            log << "m_game_state: 0x" << m_game_state << "\n";
            log << "PlayerArray offset: 0x" << squad::PlayerArray << "\n";
            if (m_game_state) {
                log << "Reading from: 0x" << (m_game_state + squad::PlayerArray) << "\n";
            } else {
                log << "ERROR: m_game_state is NULL!\n";
            }
            log.close();
        }
        
        if (!m_game_state) return;

        struct { uint64_t data; int32_t count; int32_t max; } player_array{};
        m_drv.read_raw(m_game_state + squad::PlayerArray, &player_array, sizeof(player_array));
        
        {
            std::ofstream log("playerarray_debug.txt", std::ios::app);
            log << "PlayerArray.data: 0x" << std::hex << player_array.data << "\n";
            log << "PlayerArray.count: " << std::dec << player_array.count << "\n";
            log << "PlayerArray.max: " << player_array.max << "\n";
            log.close();
        }

        if (player_array.data && player_array.count > 0 && player_array.count <= 512) {
            m_debug_stats.player_array_count = player_array.count;

                int count = player_array.count;
                std::vector<uint64_t> player_states(count);
                if (m_drv.read_raw(player_array.data, player_states.data(), count * sizeof(uint64_t))) {
                    // FIX: do NOT skip when count==1. Even if PlayerArray only
                    // replicates the local player, the actor fallback still
                    // needs diagnostics for the single entry, and when count>1
                    // but the first entries are null we must not bail early.
                    for (int i = 0; i < count; i++) {
                        uint64_t ps = player_states[i];
                        if (!ps) continue;

                        if (!m_debug_stats.first_player_state_ptr) {
                            m_debug_stats.first_player_state_ptr = ps;
                            m_debug_stats.first_player_team = m_drv.read<int32_t>(ps + squad::PS_TeamId);
                            m_debug_stats.first_player_soldier_ptr = m_drv.read<uint64_t>(ps + squad::PS_PawnPrivate);
                        }

                        m_debug_stats.player_states_scanned++;
                        process_player_state(ps);
                    }
                    if (count == 1) m_debug_stats.player_array_single_skipped = 1;
                }
        }

        // ENABLED: Actor scan to find players
        if (m_players.size() < 8) {
            read_actor_array_players();
        }
    }

    bool is_probably_valid_user_ptr(uint64_t ptr) const
    {
        return ptr > 0x10000 && ptr < 0x0000800000000000ULL && (ptr & 0x7) == 0;
    }

    bool is_player_cached(uint64_t actor, uint64_t ps) const
    {
        for (const auto& p : m_players) {
            if (p.actor == actor || (ps && p.player_state == ps)) return true;
        }
        return false;
    }

    bool is_same_player(const PlayerData& p, uint64_t actor, uint64_t ps) const
    {
        return p.actor == actor || (ps && p.player_state == ps);
    }

    void merge_player_cache()
    {
        // DISABLED: Cache preserves bad candidates from actor scan
        // Per 111.md Phase 1: Stop data pollution - disable cache feeding m_players
        constexpr uint64_t kCacheFrames = 120;

        for (auto& p : m_players) {
            p.last_seen_frame = m_frame_index;

            bool updated = false;
            for (auto& cached : m_player_cache) {
                if (is_same_player(cached, p.actor, p.player_state)) {
                    cached = p;
                    updated = true;
                    break;
                }
            }
            if (!updated) {
                m_player_cache.push_back(p);
            }
        }

        std::vector<PlayerData> next_cache;
        next_cache.reserve(m_player_cache.size());

        for (auto cached : m_player_cache) {
            uint64_t age = (m_frame_index >= cached.last_seen_frame) ? (m_frame_index - cached.last_seen_frame) : 0;
            if (age > kCacheFrames) continue;

            // DISABLED: Do not re-add cached players to render list during diagnostic phase
            // if (!m_local_position.is_zero()) {
            //     cached.distance = cached.position.distance_m(m_local_position);
            // }
            // 
            // bool already_visible = false;
            // for (const auto& p : m_players) {
            //     if (is_same_player(p, cached.actor, cached.player_state)) {
            //         already_visible = true;
            //         break;
            //     }
            // }
            // 
            // if (!already_visible && is_probably_valid_user_ptr(cached.actor)) {
            //     m_players.push_back(cached);
            //     m_debug_stats.cache_added_players++;
            // }

            next_cache.push_back(cached);
        }

        m_player_cache.swap(next_cache);
        m_debug_stats.cache_size = (int)m_player_cache.size();
        m_debug_stats.cache_added_players = 0; // Always 0 when disabled
    }

    // -----------------------------------------------------------------------
    // Actor fallback for cases where GameState::PlayerArray only exposes local.
    // -----------------------------------------------------------------------
    void read_actor_array_players()
    {
        scan_level_for_players(m_persistent_level);

        struct { uint64_t data; int32_t count; int32_t max; } levels{};
        if (!m_drv.read_raw(m_world + squad::Levels, &levels, sizeof(levels)))
            return;

        if (!levels.data || levels.count <= 0 || levels.count > 256)
            return;

        m_debug_stats.actor_level_count = levels.count;

        std::vector<uint64_t> level_ptrs(levels.count);
        if (!m_drv.read_raw(levels.data, level_ptrs.data(), levels.count * sizeof(uint64_t)))
            return;

        for (uint64_t level : level_ptrs) {
            if (!level || level == m_persistent_level) continue;
            scan_level_for_players(level);
        }
    }

    void scan_level_for_players(uint64_t level)
    {
        if (!level) return;

        struct { uint64_t data; int32_t count; int32_t max; } actor_array{};
        
        // Read ActorArray at known offset
        if (!m_drv.read_raw(level + squad::ActorArray, &actor_array, sizeof(actor_array))) {
            return;
        }
        
        if (!actor_array.data || actor_array.count <= 0 || actor_array.count > 200000)
            return;
        
        m_debug_stats.ps_handle_raw = squad::ActorArray;

        m_debug_stats.actor_arrays_scanned++;
        m_debug_stats.actor_array_count += actor_array.count;

        const int kMaxActorScan = 20000;
        int count = actor_array.count > kMaxActorScan ? kMaxActorScan : actor_array.count;

        std::vector<uint64_t> actors(count);
        if (!m_drv.read_raw(actor_array.data, actors.data(), count * sizeof(uint64_t)))
            return;

        for (uint64_t actor : actors) {
            if (!is_probably_valid_user_ptr(actor) || actor == m_local_pawn) {
                if (actor) m_debug_stats.actor_invalid_ptr++;
                continue;
            }

            m_debug_stats.actors_scanned++;
            if (!m_debug_stats.first_actor_ptr) m_debug_stats.first_actor_ptr = actor;

            // Actor IS the pawn - read PlayerState from it
            uint64_t ps = m_drv.read<uint64_t>(actor + squad::PlayerState);
            if (!is_probably_valid_user_ptr(ps)) continue;
            m_debug_stats.actors_with_player_state++;

            // Read team via TeamState pointer
            uint64_t team_state = m_drv.read<uint64_t>(ps + 0x07E0);  // ASQPlayerState::TeamState
            int32_t team_id = 0;
            if (is_probably_valid_user_ptr(team_state)) {
                team_id = m_drv.read<int32_t>(team_state + 0x02E8);  // ASQTeamState::ID
            }

            if (!m_debug_stats.first_actor_player_state_ptr) {
                m_debug_stats.first_actor_player_state_ptr = ps;
                m_debug_stats.first_actor_team = team_id;
                m_debug_stats.first_actor_soldier_ptr = actor;
            }

            // Accept all valid teams (1, 2, or even 0)
            if (team_id < 0 || team_id > 10) {
                m_debug_stats.actor_bad_team++;
                continue;
            }

            m_debug_stats.actor_scan_candidates++;
            m_debug_stats.actor_scan_actor_attempts++;
            
            if (!process_soldier_actor(ps, actor, team_id, true))
                m_debug_stats.actor_soldier_link_failed++;
        }
    }

    // -----------------------------------------------------------------------
    // Process a single PlayerState - resolve pawn using engine PawnPrivate field
    // Per 111.md: Use APlayerState::PawnPrivate (0x330), NOT ASQPlayerState::Soldier
    // -----------------------------------------------------------------------
    void process_player_state(uint64_t ps)
    {
        if (!is_probably_valid_user_ptr(ps)) return;
        m_debug_stats.with_valid_player_state++;

        // Read team via TeamState pointer
        uint64_t team_state = m_drv.read<uint64_t>(ps + 0x07E0);  // ASQPlayerState::TeamState
        int32_t team_id = 0;
        if (is_probably_valid_user_ptr(team_state)) {
            team_id = m_drv.read<int32_t>(team_state + 0x02E8);  // ASQTeamState::ID
        }
        
        if (team_id < 0 || team_id > 10) { 
            m_debug_stats.actor_bad_team++; 
            return; 
        }
        m_debug_stats.valid_team++;

        uint64_t actor = m_drv.read<uint64_t>(ps + squad::PS_PawnPrivate);
        
        static bool logged = false;
        if (!logged) {
            logged = true;
            std::ofstream log("pawn_debug.txt");
            log << std::hex;
            log << "First PlayerState: 0x" << ps << "\n";
            log << "PS_PawnPrivate offset: 0x" << squad::PS_PawnPrivate << "\n";
            log << "Reading from: 0x" << (ps + squad::PS_PawnPrivate) << "\n";
            log << "Pawn: 0x" << actor << "\n";
            log << "Team: " << std::dec << team_id << "\n";
            log.close();
        }
        
        if (!is_probably_valid_user_ptr(actor)) {
            m_debug_stats.actor_invalid_ptr++;
            return;
        }

        process_soldier_actor(ps, actor, team_id, false);
    }

    bool process_soldier_actor(uint64_t ps, uint64_t actor, int32_t team_id, bool from_actor_scan)
    {
        if (!is_probably_valid_user_ptr(ps) || !is_probably_valid_user_ptr(actor)) {
            m_debug_stats.actor_invalid_ptr++;
            return false;
        }
        if (actor == m_local_pawn) return false;
        if (is_player_cached(actor, ps)) return false;

        uint64_t actor_ps = m_drv.read<uint64_t>(actor + squad::PlayerState);
        if (actor_ps != ps) {
            m_debug_stats.actor_backcheck_failed++;
            return false;
        }
        m_debug_stats.valid_soldier++;

        uint64_t mesh = m_drv.read<uint64_t>(actor + squad::CharacterMesh);
        if (!is_probably_valid_user_ptr(mesh)) {
            m_debug_stats.actor_mesh_failed++;
            return false;
        }

        uint64_t root = m_drv.read<uint64_t>(actor + squad::RootComponent);
        if (!is_probably_valid_user_ptr(root)) {
            m_debug_stats.actor_root_failed++;
            return false;
        }

        FVector position{};
        float health = 0.f;
        uint8_t dying_flags = 0;

        // Read position from RelativeLocation (for root component, this IS world position)
        std::vector<SquadDriver::BatchReq> batch = {
            { root + squad::RelativeLocation, sizeof(FVector), &position },
            { actor + squad::Health, sizeof(float), &health },
            { actor + squad::DyingFlags, sizeof(uint8_t), &dying_flags },
        };
        if (!m_drv.batch_read(batch)) {
            m_debug_stats.actor_health_failed++;
            return false;
        }

        static int debug_count = 0;
        if (debug_count < 3) {
            std::ofstream log("position_debug.txt", std::ios::app);
            log << std::hex;
            log << "Actor: 0x" << actor << "\n";
            log << "Root: 0x" << root << "\n";
            log << "Reading from: 0x" << (root + squad::RelativeLocation) << "\n";
            log << std::dec;
            log << "Position: " << position.x << ", " << position.y << ", " << position.z << "\n";
            log << "Health: " << health << "\n\n";
            log.close();
            debug_count++;
        }

        bool is_dying = (dying_flags & 0x01) != 0;
        
        // Temporarily disable health validation - health offset needs fixing
        if (health < 0.f || health > 500.f) {
            health = 100.f;  // Default to 100 if invalid
        }
        m_debug_stats.valid_health++;
        
        if (position.is_zero()) {
            m_debug_stats.actor_root_failed++;
            return false;
        }

        PlayerData pd{};
        pd.actor = actor;
        pd.mesh = mesh;
        pd.player_state = ps;
        pd.position = position;
        pd.health = health;
        pd.team_id = team_id;
        pd.dying_flags = dying_flags;
        pd.is_alive = !is_dying;
        pd.last_seen_frame = m_frame_index;

        if (!m_local_position.is_zero()) {
            pd.distance = position.distance_m(m_local_position);
        } else if (m_local_pawn) {
            uint64_t local_root = m_drv.read<uint64_t>(m_local_pawn + squad::RootComponent);
            if (local_root) {
                FVector local_pos{};
                m_drv.read_raw(local_root + squad::RelativeLocation, &local_pos, sizeof(FVector));
                pd.distance = position.distance_m(local_pos);
            }
        }

        pd.name = m_drv.read_fstring(ps + squad::PlayerNamePrivate);

        pd.bones_valid = read_bones(mesh, pd);
        if (pd.bones_valid && !pd.head_pos.is_zero()) {
            m_debug_stats.valid_bones++;
        } else {
            pd.bones_valid = false;
            pd.head_pos = pd.position + FVector(0.0, 0.0, 180.0);
            m_debug_stats.actor_bones_failed++;
            m_debug_stats.actor_estimated_head++;
        }

        m_players.push_back(std::move(pd));
        m_debug_stats.pushed_players++;
        if (from_actor_scan) m_debug_stats.actor_scan_pushed++;
        return true;
    }

    // -----------------------------------------------------------------------
    // Read skeleton bones for a mesh component
    // -----------------------------------------------------------------------
    bool read_bones(uint64_t mesh, PlayerData& pd)
    {
        m_debug_stats.bone_attempts++;
        if (!m_debug_stats.first_bone_mesh) m_debug_stats.first_bone_mesh = mesh;

        FTransform comp_to_world{};
        if (!m_drv.read_raw(mesh + squad::ComponentToWorld, &comp_to_world, sizeof(FTransform))) {
            m_debug_stats.bone_comp_fail++;
            return false;
        }

        auto head_is_reasonable = [&](const FVector& head) -> bool {
            if (head.is_zero()) return false;
            double root_delta = (head - pd.position).length();
            double z_delta = fabs(head.z - pd.position.z);
            return root_delta > 20.0 && root_delta < 650.0 && z_delta < 450.0;
        };

        auto try_bone_offset = [&](uint64_t bone_offset, bool count_invalid, bool from_scan) -> bool {
            struct { uint64_t data; int32_t count; int32_t max; } bone_arr{};
            if (!m_drv.read_raw(mesh + bone_offset, &bone_arr, sizeof(bone_arr))) {
                if (count_invalid) m_debug_stats.bone_array_fail++;
                return false;
            }

            if (!m_debug_stats.first_bone_offset) {
                m_debug_stats.first_bone_offset = bone_offset;
                m_debug_stats.first_bone_array = bone_arr.data;
                m_debug_stats.first_bone_count = bone_arr.count;
                m_debug_stats.first_bone_max = bone_arr.max;
            }

            bool valid_array = is_probably_valid_user_ptr(bone_arr.data) &&
                bone_arr.count >= 8 && bone_arr.count <= 512 &&
                bone_arr.max >= bone_arr.count && bone_arr.max <= 1024;
            if (!valid_array) {
                if (count_invalid) m_debug_stats.bone_array_invalid++;
                return false;
            }

            if (from_scan) {
                m_debug_stats.bone_scan_candidates++;
                if (!m_debug_stats.first_scan_bone_offset) {
                    m_debug_stats.first_scan_bone_offset = bone_offset;
                    m_debug_stats.first_scan_bone_array = bone_arr.data;
                    m_debug_stats.first_scan_bone_count = bone_arr.count;
                    m_debug_stats.first_scan_bone_max = bone_arr.max;
                }
            }

            int max_bone = (bone_arr.count > 141) ? 141 : bone_arr.count;
            size_t read_size = max_bone * sizeof(FTransform);
            if (read_size > 50000) {
                m_debug_stats.bone_read_fail++;
                return false;
            }

            std::vector<FTransform> bone_transforms(max_bone);
            if (!m_drv.read_raw(bone_arr.data, bone_transforms.data(), read_size)) {
                m_debug_stats.bone_read_fail++;
                return false;
            }

            for (int i = 0; i < max_bone; i++) {
                pd.bones_ws[i] = transform_bone_to_world(comp_to_world, bone_transforms[i]);
            }

            FVector head{};
            if (max_bone > squad::bones::Head) {
                head = pd.bones_ws[squad::bones::Head];
                if (!head_is_reasonable(head) && max_bone > squad::bones::HeadNub) {
                    head = pd.bones_ws[squad::bones::HeadNub];
                }
            }

            if (!head_is_reasonable(head)) {
                if (from_scan) m_debug_stats.bone_scan_rejected++;
                else m_debug_stats.bone_head_zero++;
                return false;
            }

            pd.head_pos = head;
            m_debug_stats.used_bone_offset = bone_offset;
            m_debug_stats.used_bone_count = bone_arr.count;
            return true;
        };

        // FIX: only try COMPONENT-space arrays, since transform_bone_to_world()
        // assumes component-space input. CachedBoneSpaceTransforms is stored in
        // parent-bone-local space and would require a parent-chain walk that we
        // don't perform, so it used to poison the "head_is_reasonable" check and
        // cause valid meshes to be rejected.
        const uint64_t candidates[] = {
            squad::CachedComponentSpaceTransforms,          // 0x0998 - primary
            squad::CachedComponentSpaceTransforms + 0x10,   // some builds swap alignment
            squad::CachedComponentSpaceTransforms - 0x10,
        };

        for (uint64_t bone_offset : candidates) {
            if (try_bone_offset(bone_offset, true, false)) return true;
        }

        // Brute-force scan only for the very first mesh we ever see, and only
        // narrowly around the known-good region. This gives us a recovery path
        // if the engine layout shifted, without the pathological false-positives
        // the previous 0x0400..0x1200 range produced.
        if (m_debug_stats.bone_attempts <= 1) {
            for (uint64_t bone_offset = 0x0900; bone_offset <= 0x0AA0; bone_offset += 0x8) {
                m_debug_stats.bone_scan_checked++;
                if (try_bone_offset(bone_offset, false, true)) return true;
            }
        }

        return false;
    }
};
