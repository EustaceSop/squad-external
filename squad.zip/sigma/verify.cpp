#include "driver.hpp"
#include "offsets.hpp"
#include <iostream>

int main()
{
    SquadDriver drv;
    if (!drv.connect() || !drv.attach()) {
        std::cerr << "[!] Failed\n";
        return 1;
    }
    
    uint64_t base = drv.base();
    std::cout << "[+] Base: 0x" << std::hex << base << "\n\n";

    // Test GObjects
    struct { uint64_t ptr; uint32_t num; uint32_t max; } gobj = {};
    drv.read_raw(base + squad::GObjects, &gobj, sizeof(gobj));
    std::cout << "[GObjects] 0x" << std::hex << squad::GObjects << "\n";
    std::cout << "  NumElements: " << std::dec << gobj.num << "\n";
    std::cout << "  MaxElements: " << gobj.max << "\n";
    std::cout << "  Status: " << (gobj.num > 10000 && gobj.num < 500000 ? "OK" : "FAIL") << "\n\n";

    // Test GWorld
    uint64_t world_ptr = 0;
    drv.read_raw(base + squad::GWorld, &world_ptr, 8);
    std::cout << "[GWorld] 0x" << std::hex << squad::GWorld << "\n";
    std::cout << "  UWorld ptr: 0x" << world_ptr << "\n";
    
    if (world_ptr > base && world_ptr < base + 0x20000000) {
        uint64_t level = 0, state = 0;
        drv.read_raw(world_ptr + 0x30, &level, 8);
        drv.read_raw(world_ptr + 0x1B0, &state, 8);
        std::cout << "  PersistentLevel: 0x" << level << "\n";
        std::cout << "  GameState: 0x" << state << "\n";
        std::cout << "  Status: OK\n";
    } else {
        std::cout << "  Status: FAIL\n";
    }

    return 0;
}
