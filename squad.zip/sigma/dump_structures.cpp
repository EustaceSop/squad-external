#include "driver.hpp"
#include "offsets.hpp"
#include <iostream>
#include <iomanip>
#include <fstream>

void dump_hex(std::ofstream& out, const char* name, uint64_t addr, SquadDriver& drv, int size) {
    out << "\n=== " << name << " @ 0x" << std::hex << addr << " ===\n";
    
    for (int i = 0; i < size; i += 0x10) {
        out << "+0x" << std::setw(4) << std::setfill('0') << i << ": ";
        
        for (int j = 0; j < 0x10 && i + j < size; j += 8) {
            uint64_t val = drv.read<uint64_t>(addr + i + j);
            out << std::setw(16) << std::setfill('0') << val << " ";
        }
        out << "\n";
    }
}

int main()
{
    SquadDriver drv;
    if (!drv.connect() || !drv.attach()) {
        std::cout << "Failed to connect\n";
        return 1;
    }
    
    std::ofstream out("squad_dump.txt");
    uint64_t base = drv.base();
    
    out << "Base: 0x" << std::hex << base << "\n";
    
    // Read World
    uint64_t world = drv.read<uint64_t>(base + squad::GWorld);
    out << "World: 0x" << world << "\n";
    
    if (world) {
        // Dump World structure
        dump_hex(out, "UWorld", world, drv, 0x300);
        
        // Read Level
        uint64_t level = drv.read<uint64_t>(world + squad::PersistentLevel);
        out << "\nLevel: 0x" << level << "\n";
        
        if (level) {
            // Dump Level structure
            dump_hex(out, "ULevel", level, drv, 0x300);
        }
        
        // Read GameState
        uint64_t gs = drv.read<uint64_t>(world + squad::GameState);
        out << "\nGameState: 0x" << gs << "\n";
        
        if (gs) {
            // Dump GameState structure
            dump_hex(out, "AGameStateBase", gs, drv, 0x400);
        }
    }
    
    out.close();
    std::cout << "Dump saved to squad_dump.txt\n";
    std::cout << "Look for TArray patterns: [ptr][count][max]\n";
    std::cout << "Valid pointers start with 0x7FF7...\n";
    
    return 0;
}
