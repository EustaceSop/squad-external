#include "driver.hpp"
#include <iostream>
#include <iomanip>

int main()
{
    SquadDriver drv;
    if (!drv.connect() || !drv.attach()) return 1;
    
    uint64_t pawn = 0x7FF780A5B0D0;  // From debug output
    
    std::cout << "[+] Dumping Pawn structure at 0x" << std::hex << pawn << "\n\n";
    
    // Dump 0x2C0 to 0x320
    for (uint64_t off = 0x2C0; off <= 0x320; off += 0x8) {
        uint64_t val = drv.read<uint64_t>(pawn + off);
        std::cout << "  +0x" << std::setw(3) << std::setfill('0') << off << ": 0x" << std::setw(16) << std::setfill('0') << val;
        
        // Check if valid pointer
        if (val >= 0x7FF700000000 && val < 0x7FFF00000000) {
            std::cout << " [PTR]";
        }
        std::cout << "\n";
    }
    
    return 0;
}
