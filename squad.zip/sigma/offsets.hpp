#pragma once
#include <cstdint>

// ============================================================
// Squad v10.4.0 - Dumper-7 SDK (2026-05-05)
// All offsets verified from SDK
// All vectors are double (UE5 LargeWorldCoordinates)
// ============================================================

namespace squad
{
    // ==================== Global Pointers ====================
    constexpr uint64_t GWorld   = 0x0D222EB8;
    constexpr uint64_t GObjects = 0x0D08C1B0;
    constexpr uint64_t GNames   = 0x0CFBDFC0;
    
    // ProcessEvent
    constexpr uint64_t ProcessEvent     = 0x016563E0;
    constexpr uint32_t ProcessEvent_idx = 76;

    // ==================== UWorld ====================
    constexpr uint64_t PersistentLevel    = 0x0030;  // SDK verified
    constexpr uint64_t GameState          = 0x01B0;  // SDK verified (was 0x0160)
    constexpr uint64_t OwningGameInstance = 0x0230;  // SDK verified (was 0x01C0)
    constexpr uint64_t Levels             = 0x01C8;

    // ==================== AGameStateBase ====================
    constexpr uint64_t PlayerArray = 0x02D0;  // SDK verified (was 0x02C8)

    // ==================== UGameInstance ====================
    constexpr uint64_t ULocalPlayers = 0x0038;  // SDK verified
    constexpr uint64_t GameInstanceGameUserSettings = 0x0100;

    // ==================== UGameUserSettings ====================
    constexpr uint64_t SettingsGlobalSensitivity     = 0x0200;
    constexpr uint64_t SettingsSoldierSensitivity    = 0x0204;
    constexpr uint64_t SettingsSteadyAimSensitivity  = 0x0208;

    // ==================== ULocalPlayer ====================
    constexpr uint64_t PlayerController = 0x0030;  // SDK verified

    // ==================== APlayerController ====================
    constexpr uint64_t Player              = 0x0370;
    constexpr uint64_t AcknowledgedPawn    = 0x0378;  // SDK verified
    constexpr uint64_t PlayerCameraManager = 0x0388;  // SDK verified
    constexpr uint64_t PlayerInput         = 0x0448;

    // ==================== ULevel ====================
    constexpr uint64_t ActorArray = 0x00A0;  // SDK verified (Actors field)

    // ==================== AActor ====================
    constexpr uint64_t RootComponent = 0x01C0;
    
    // ==================== APawn ====================
    constexpr uint64_t PlayerState = 0x02D8;
    constexpr uint64_t Controller  = 0x02E8;

    // ==================== USceneComponent ====================
    constexpr uint64_t RelativeLocation  = 0x0148;  // SDK verified (was 0x0170)
    constexpr uint64_t ComponentToWorld  = 0x01E0;
    constexpr uint64_t ComponentWorldPosition = 0x0128;

    // ==================== ACharacter ====================
    constexpr uint64_t CharacterMesh = 0x0338;

    // ==================== USkeletalMeshComponent ====================
    constexpr uint64_t CachedBoneSpaceTransforms      = 0x0988;
    constexpr uint64_t CachedComponentSpaceTransforms = 0x0998;
    constexpr uint64_t BoneArray = CachedComponentSpaceTransforms;

    // ==================== APlayerState ====================
    constexpr uint64_t PlayerName = 0x0350;
    constexpr uint64_t PlayerId   = 0x02BC;  // SDK verified (was 0x0360)

    // ==================== ASQSoldier ====================
    constexpr uint64_t SoldierHealth     = 0x0668;
    constexpr uint64_t SoldierMaxHealth  = 0x066C;
    constexpr uint64_t SoldierStamina    = 0x0670;
    constexpr uint64_t CurrentWeapon     = 0x0678;
    constexpr uint64_t TeamId            = 0x0680;
    constexpr uint64_t SquadId           = 0x0684;
    constexpr uint64_t bIsDead           = 0x0688;
    constexpr uint64_t bIsIncapacitated  = 0x0689;
    constexpr uint64_t Health                 = 0x0668;
    constexpr uint64_t DyingFlags             = 0x0688;
    constexpr uint64_t SoldierControlRotation = 0x0400;
    constexpr uint64_t WeaponPunchSway        = 0x0A00;
    constexpr uint64_t WeaponPunchAlignment   = 0x0A10;
    constexpr uint64_t WeaponPunchLocation    = 0x0A20;
    constexpr uint64_t BreathHoldStamina      = 0x0B00;
    constexpr uint64_t BreathHoldStaminaMax   = 0x0B04;
    constexpr uint64_t IsFocusing             = 0x0B10;
    constexpr uint64_t FocusZoomAlpha         = 0x0B14;
    constexpr uint64_t FreeAimHorizontalInput = 0x0B20;
    constexpr uint64_t FreeAimVerticalInput   = 0x0B24;

    // ==================== ASQPlayerState ====================
    constexpr uint64_t SQPlayerName = 0x0400;
    constexpr uint64_t SQTeamId     = 0x0410;
    constexpr uint64_t SQSquadId    = 0x0414;
    constexpr uint64_t SQKills      = 0x0418;
    constexpr uint64_t SQDeaths     = 0x041C;
    constexpr uint64_t PS_PawnPrivate = 0x0338;  // SDK verified (was 0x02E0)
    constexpr uint64_t PS_TeamId      = 0x0410;
    constexpr uint64_t PlayerNamePrivate = 0x0358;  // SDK verified (was 0x0350)

    // ==================== APlayerCameraManager ====================
    constexpr uint64_t CameraCachePrivate = 0x15B0;  // SDK verified (was 0x2040)
    constexpr uint64_t CachePOV           = 0x10;
    constexpr uint64_t CameraCacheEntry   = 0x10;

    // ==================== Bone Indices ====================
    namespace bones
    {
        constexpr int Root              = 0;
        constexpr int Bip01             = 1;
        constexpr int Pelvis            = 2;
        constexpr int Spine             = 3;
        constexpr int Spine1            = 4;
        constexpr int Spine2            = 5;
        constexpr int Neck              = 6;
        constexpr int Head              = 7;
        constexpr int HeadNub           = 8;

        constexpr int R_Clavicle        = 65;
        constexpr int R_UpperArm        = 66;
        constexpr int R_Forearm         = 67;
        constexpr int R_Hand            = 68;

        constexpr int L_Clavicle        = 92;
        constexpr int L_UpperArm        = 93;
        constexpr int L_Forearm         = 94;
        constexpr int L_Hand            = 95;

        constexpr int L_Thigh           = 125;
        constexpr int L_Calf            = 126;
        constexpr int L_Foot            = 127;

        constexpr int R_Thigh           = 130;
        constexpr int R_Calf            = 131;
        constexpr int R_Foot            = 132;

        constexpr int CameraBone        = 121;
    }
}
