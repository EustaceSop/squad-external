@echo off
cd /d D:\Download\squad\sigma
"C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe" ud.sln /p:Configuration=Release /p:Platform=x64 /v:minimal
pause
