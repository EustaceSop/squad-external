#pragma once
#include "driver.hpp"
#include "offsets.hpp"

// UE5 TObjectPtr resolver
class ObjectResolver
{
    SquadDriver& m_drv;
    
public:
    uint64_t m_gobjects_ptr = 0;
    uint64_t m_objects_array = 0;
    
    ObjectResolver(SquadDriver& drv) : m_drv(drv) {}
    
    uint64_t resolve(uint64_t handle)
    {
        // If high 32 bits are 0, it's a direct pointer
        if ((handle >> 32) == 0) return handle;
        
        // Extract index from low 32 bits
        uint32_t index = (uint32_t)(handle & 0xFFFFFFFF);
        
        // Lazy init GObjects
        if (!m_gobjects_ptr) {
            m_gobjects_ptr = m_drv.read<uint64_t>(m_drv.base() + squad::GObjects);
        }
        
        if (!m_gobjects_ptr) return 0;
        
        // GObjects is FUObjectArray
        if (!m_objects_array) {
            m_objects_array = m_drv.read<uint64_t>(m_gobjects_ptr);
        }
        if (!m_objects_array) return 0;
        
        // Try 0x18 first (common size)
        uint64_t item_ptr = m_objects_array + (index * 0x18);
        uint64_t object = m_drv.read<uint64_t>(item_ptr);
        
        // Validate pointer
        uint64_t base = m_drv.base();
        if (object >= base && object < base + 0x30000000) {
            return object;
        }
        
        // Try 0x20 if 0x18 failed
        item_ptr = m_objects_array + (index * 0x20);
        object = m_drv.read<uint64_t>(item_ptr);
        if (object >= base && object < base + 0x30000000) {
            return object;
        }
        
        return 0;
    }
};
