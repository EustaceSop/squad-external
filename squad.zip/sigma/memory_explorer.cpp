#include "driver.hpp"
#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>

void dump_memory(SquadDriver& drv, uint64_t addr, size_t size = 0x100)
{
    uint64_t base = drv.base();
    std::cout << "\n=== Memory @ 0x" << std::hex << addr << " ===\n";
    
    for (size_t off = 0; off < size; off += 0x10) {
        std::cout << "+0x" << std::setw(3) << std::setfill('0') << off << ": ";
        
        for (int i = 0; i < 2; i++) {
            uint64_t val = drv.read<uint64_t>(addr + off + i * 8);
            std::cout << std::setw(16) << std::setfill('0') << val << " ";
            
            // Mark if valid pointer
            if (val >= base && val < base + 0x30000000) {
                std::cout << "[PTR] ";
            }
        }
        std::cout << "\n";
    }
}

void scan_for_tarray(SquadDriver& drv, uint64_t addr, size_t range = 0x200)
{
    uint64_t base = drv.base();
    std::cout << "\n=== Scanning for TArray @ 0x" << std::hex << addr << " ===\n";
    
    for (size_t off = 0; off < range; off += 0x8) {
        uint64_t ptr = drv.read<uint64_t>(addr + off);
        int32_t count = drv.read<int32_t>(addr + off + 0x8);
        
        if (ptr >= base && ptr < base + 0x30000000 && count > 10 && count < 5000) {
            std::cout << "+0x" << std::hex << std::setw(3) << std::setfill('0') << off 
                     << ": TArray[" << std::dec << count << "] @ 0x" << std::hex << ptr << "\n";
        }
    }
}

int main()
{
    SquadDriver drv;
    if (!drv.connect() || !drv.attach()) {
        std::cout << "Failed to attach\n";
        return 1;
    }
    
    uint64_t base = drv.base();
    std::cout << "Base: 0x" << std::hex << base << "\n";
    std::cout << "Commands:\n";
    std::cout << "  d <addr> [size]  - Dump memory\n";
    std::cout << "  r <addr>         - Read qword\n";
    std::cout << "  s <addr>         - Scan for TArray\n";
    std::cout << "  g <offset>       - Read GWorld at offset\n";
    std::cout << "  q                - Quit\n\n";
    
    std::string line;
    while (true) {
        std::cout << "> ";
        if (!std::getline(std::cin, line)) break;
        
        std::istringstream iss(line);
        std::string cmd;
        iss >> cmd;
        
        if (cmd == "q") break;
        
        if (cmd == "d") {
            uint64_t addr;
            size_t size = 0x100;
            iss >> std::hex >> addr;
            if (iss >> size) {}
            dump_memory(drv, addr, size);
        }
        else if (cmd == "r") {
            uint64_t addr;
            iss >> std::hex >> addr;
            uint64_t val = drv.read<uint64_t>(addr);
            std::cout << "0x" << std::hex << addr << " = 0x" << val << "\n";
        }
        else if (cmd == "s") {
            uint64_t addr;
            iss >> std::hex >> addr;
            scan_for_tarray(drv, addr);
        }
        else if (cmd == "g") {
            uint64_t offset;
            iss >> std::hex >> offset;
            uint64_t gworld = drv.read<uint64_t>(base + offset);
            std::cout << "GWorld @ base+0x" << std::hex << offset << " = 0x" << gworld << "\n";
            
            if (gworld >= base && gworld < base + 0x30000000) {
                std::cout << "Valid pointer! Dumping...\n";
                dump_memory(drv, gworld);
            }
        }
        else {
            std::cout << "Unknown command\n";
        }
    }
    
    return 0;
}
