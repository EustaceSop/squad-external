#include "driver.hpp"
#include <fstream>
#include <iostream>

int main()
{
    SquadDriver drv;
    if (!drv.connect() || !drv.attach()) {
        std::cout << "Failed to attach\n";
        return 1;
    }
    
    uint64_t base = drv.base();
    std::cout << "Base: 0x" << std::hex << base << "\n";
    
    // Dump .data section (0x0A000000 - 0x10000000, ~96MB)
    std::ofstream out("squad_data_dump.bin", std::ios::binary);
    
    const size_t chunk_size = 0x100000; // 1MB chunks
    uint8_t buffer[chunk_size];
    
    for (uint64_t off = 0x0A000000; off < 0x10000000; off += chunk_size) {
        std::cout << "Dumping 0x" << std::hex << off << "\r" << std::flush;
        
        if (drv.read_raw(base + off, buffer, chunk_size)) {
            out.write((char*)buffer, chunk_size);
        } else {
            // Write zeros for failed reads
            memset(buffer, 0, chunk_size);
            out.write((char*)buffer, chunk_size);
        }
    }
    
    out.close();
    std::cout << "\nDump complete: squad_data_dump.bin\n";
    std::cout << "Use a hex editor to search for patterns\n";
    
    return 0;
}
