# Dump UWorld structure at runtime
import sys

gworld_value = 0x26a4c13d560
base = 0x7ff632450000

print(f"Scanning UWorld @ 0x{gworld_value:X} for PersistentLevel...")
print(f"Valid range: 0x{base:X} - 0x{base + 0x30000000:X}")
print()

# We need to find which offset contains a valid pointer
# PersistentLevel should be within first 0x200 bytes
for off in range(0, 0x200, 8):
    print(f"+0x{off:03X}: [need runtime read]")
