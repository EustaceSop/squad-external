#pragma once
#include "driver.hpp"
#include "offsets.hpp"
#include "structs.hpp"

class SquadExploit
{
public:
    SquadExploit(SquadDriver& drv) : m_drv(drv) {}

    // Feature toggles
    bool no_sway       = false;
    bool no_recoil     = false;
    bool infinite_breath = false;

    void tick(uint64_t local_pawn)
    {
        if (!local_pawn) return;

        // Build batch of all writes we need
        std::vector<SquadDriver::BatchWriteReq> writes;

        if (no_sway) {

            static FRotator zero_rot = { 0.0, 0.0, 0.0 };
            static FVector  zero_vec = { 0.0, 0.0, 0.0 };

            writes.push_back({ local_pawn + squad::WeaponPunchSway, sizeof(FRotator), &zero_rot });
            writes.push_back({ local_pawn + squad::WeaponPunchAlignment, sizeof(FRotator), &zero_rot });
            writes.push_back({ local_pawn + squad::WeaponPunchLocation, sizeof(FVector),  &zero_vec });
        }

        if (no_recoil) {

            static float zero_f = 0.f;

            writes.push_back({ local_pawn + squad::FreeAimVerticalInput, sizeof(float), &zero_f });
            writes.push_back({ local_pawn + squad::FreeAimHorizontalInput, sizeof(float), &zero_f });
        }

        if (infinite_breath) {

            float max_stamina = m_drv.read<float>(local_pawn + squad::BreathHoldStaminaMax, 2);
            if (max_stamina <= 0.f) max_stamina = 1.0f; // fallback

            writes.push_back({ local_pawn + squad::BreathHoldStamina, sizeof(float), &max_stamina });
        }

        if (!writes.empty()) {
            m_drv.batch_write(writes, 2);
        }
    }

private:
    SquadDriver& m_drv;
};
